package com.example.dailygoals

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SimpleApp()
        }
    }
}

@Composable
fun SimpleApp() {
    var text by remember { mutableStateOf("") }
    var items by remember { mutableStateOf(listOf<Pair<String, Boolean>>()) }

    Column(modifier = Modifier.padding(16.dp)) {

        Text("Daily Goals", fontSize = 24.sp)

        Spacer(Modifier.height(10.dp))

        TextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("Goal") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                if (text.isNotBlank()) {
                    items = items + (text to false)
                    text = ""
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Add")
        }

        Spacer(Modifier.height(16.dp))

        items = items // no-op to avoid lint

        items.forEachIndexed { index, item ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row {
                    Checkbox(
                        checked = item.second,
                        onCheckedChange = {
                            items = items.toMutableList().also {
                                it[index] = item.first to !item.second
                            }
                        }
                    )
                    Text(item.first)
                }

                Text("🗑")
            }
        }
    }
}
